export const slider = [
    {   
        id:1,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/YAYZINGER.jpg",
        title:'FREE CHICKEN...',
        detail:'Free Chicken Zinger on cart value of 499 or more. Friday only'
    },
    {
        id:2,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/YAYPOP.jpg",
        title:"FREE POPCORN...",
        detail:"Free Popcorn (Med) on a cart value of 499 or more. Friday only.",
    },
    {
        id:3,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/YAYCHKN.jpg",
        title:"FREE 1PC CHICKEN...",
        detail:"Free 1pc Chicken on a cart value of 499 or more. Friday only.",
    },
    {
        id:4,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/YAYSTRIPS.jpg",
        title:"FREE 3PC STRIPS O...",
        detail:"Free 3pc Strips on a cart value of 499 or more. Friday only.",
    },
    {
        id:5,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/YAYVZINGER.jpg",
        title:"FREE VEG ZINGER 0..",
        detail:"Free Veg Zinger on a cart value of 499 or more. Friday only",
    },
    {
        id:6,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/YAYFRIES.jpg",
        title:"FREE FRIES (MED) ...",
        detail:"Free Fries (Med) on a cart value of 499 or more. Friday only."
    },
    {
        id:7,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/ADDCHK99.jpg",
        title:"ADD 2 PC HOT N...",
        detail:"Add 2 Pc Hot n Crispy Chicken @ just Rs 99 on min cart value od Rs 499 or more..."
    },
    {
        id:8,
        image:"https://orderserv-kfc-assets.yum.com/15895bb59f7b4bb588ee933f8cd5344a/images/offers/lg/BIGSAVE.jpg",
        title:"UPTO RS 100 OFF 0...",
        detail:"Upto Rs 100 off on min cart value of Rs 599 or more. Applicable on 4th order onward..."
    }
]