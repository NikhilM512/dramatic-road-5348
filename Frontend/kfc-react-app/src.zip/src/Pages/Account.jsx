import React from "react";

function Account() {
  return <div>this account page to show account details.</div>;
}

export default Account;
